public class System {
    static Io out;
    static Io in;
    static void exit() { java.lang.System.exit(1); }
}