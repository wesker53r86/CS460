public class Math {
    public static int min(int x, int y) {
	return (x < y) ? x : y;
    }

    public static double abs(double x) {
	return (x < 0) ? -1*x : x;
    }
}